import sqlite3
import hashlib

DATABASE = 'app.db'
db = sqlite3.connect(DATABASE)
cursor = db.cursor()

# Creation of table "categories". If it existed already,
# we delete the table and create a new one

cursor.execute('DROP TABLE IF EXISTS categories')
cursor.execute("""CREATE TABLE categories
               (id INTEGER PRIMARY KEY AUTOINCREMENT,
                name VARCHAR(200) NOT NULL,
                description VARCHAR(200) default None
                )""")

# We seed the table with initial values for test purpose.
for name in ['Beef', 'Breakfast', 'Chicken', 'Dessert', 'Goat', 'Lamb', 'Miscellaneous', 'Pasta', 'Pork', 'Seafood', 'Side', 'Starter', 'Vegan', 'Vegetarian']:
  cursor.execute('INSERT INTO categories (name) VALUES (?)', (name,))

cursor.execute('DROP TABLE IF EXISTS accounts')
cursor.execute("""CREATE TABLE accounts
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                email VARCHAR(200) NOT NULL,
                password VARCHAR(200) NOT NULL,
                salt VARCHAR(200) NOT NULL
                )""")

# for (mail, password, salt) in (['test@gmail.com', 'azerty', 'sel'], ['test2@gmail.com', 'azerty1', 'sel'], ['test3@hotmail.fr', 'azerty2', 'sel']):
#     cursor.execute('INSERT INTO accounts (email, password, salt) VALUES (?, ?, ?)', (mail, password, salt))

for (mail, password, salt) in (['test@gmail.com', 'azerty', 'sel'], ['test2@gmail.com', 'azerty1', 'sel'], ['test3@hotmail.fr', 'azerty2', 'sel']):
    temporary = password + salt
    cursor.execute('INSERT INTO accounts (email, password, salt) VALUES (?, ?, ?)', (mail, hashlib.sha256(temporary.encode('utf-8')).hexdigest(), salt))

cursor.execute('DROP TABLE IF EXISTS favorites')
cursor.execute("""CREATE TABLE favorites
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                mealId INTEGER NOT NULL,
                account_id INTEGER not null,
                CONSTRAINT fk_accounts
                  FOREIGN KEY (account_id)
                  REFERENCES accounts(id)
                )""")

for (mealId, account_id) in ([int('52878'), int('1')], [int('52911'), int('1')]):
  cursor.execute('INSERT INTO favorites (mealId, account_id) VALUES (?,?)', (mealId, account_id,))

db.commit()
db.close()