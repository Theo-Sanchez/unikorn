import sqlite3
import json
from flask import Flask, g, request, jsonify
from datetime import datetime, timedelta, timezone
from flask_jwt_extended import create_access_token,get_jwt,get_jwt_identity, \
                               unset_jwt_cookies, jwt_required, JWTManager
import random
import string
import hashlib

app = Flask(__name__)
DATABASE = '../app.db' # potentiellement besoin d'aller la chercher avec os.path

def get_db():
    '''open database'''

    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db


def query_db(query, args=(), one=False):
    '''return the select request from db.
    Only one row if one=True'''

    cur = get_db().execute(query, args)
    rv = cur.fetchall()
    cur.close()
    return (rv[0] if rv else None) if one else rv


def change_db(query, args=()):
    '''change something in the db'''

    cur = get_db().execute(query, args)
    get_db().commit()
    cur.close()

def check_unique_mail(mail):
    '''check if a mail hasn't been already used'''

    cur = query_db('select email from accounts')
    for i in range(len(cur)):
        if mail == cur[i]['email']:
            print('mail alr exist')
            return False
    return True


# def generate_salt():
#     '''65-90 AZ 97-122 az'''

#     salt = ''
#     for i in range(10):
#         x = random.randint(0, 25)
#         set = random.randint(0, 1)
#         if set:
#             salt += chr(65+x)
#         else:
#             salt += chr(97+x)
#     return salt

def generate_salt(length=10):
    
    salt = ''.join(random.choice(string.ascii_letters) for i in range(length))
    return salt

def secure(password):
    '''return sha 256 + salt'''

    salt = generate_salt()
    to_encode = password + salt
    securePassword = hashlib.sha256(to_encode.encode('utf-8')).hexdigest()
    return securePassword, salt

def check_password(passwordDB, salt, passwordForm):
    
    to_encode = passwordForm + salt
    passwordToCheck = hashlib.sha256(to_encode.encode('utf-8')).hexdigest()
    if passwordDB != passwordToCheck:
        print(f"expectedPassword: {passwordDB}, securePassword: {passwordToCheck}")
        return False
    return True



app = Flask(__name__)

app.config["JWT_SECRET_KEY"] = "clef-secrète-à-remplacer" #
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(hours=1)
jwt = JWTManager(app)

@app.after_request
def refresh_expiring_jwts(response):
    try:
        exp_timestamp = get_jwt()["exp"]
        now = datetime.now(timezone.utc)
        target_timestamp = datetime.timestamp(now + timedelta(minutes=30))
        if target_timestamp > exp_timestamp:
            access_token = create_access_token(identity=get_jwt_identity())
            data = response.get_json()
            if type(data) is dict:
                data["access_token"] = access_token 
                response.data = json.dumps(data)
        return response
    except (RuntimeError, KeyError):
        return response




@app.route("/logout", methods=["POST"])
def logout():
    response = jsonify({"msg": "logout successful"})
    unset_jwt_cookies(response)
    return response

@app.route('/signin', methods=["POST"])
def create_token():

    email = request.json.get("email", None)
    password = request.json.get("password", None)

    cur = query_db('select * from accounts where email=?', (email,)) # pue la merde?
    if len(cur) == 0:
        print(f"No record for {email}")
        return {"msg": "Wrong email or password"}, 401
    
    elif not check_password(cur[0]['password'], cur[0]['salt'], password):
        print(f'No match for this mail and password')
        return {"msg": "Wrong email or password"}, 401

    cur = query_db('select * from favorites where account_id=?', (cur[0]['id'],))
    favorites = []
    for elem in cur:
        favorites += [elem['mealId']]
    access_token = create_access_token(identity=email)

    response = {"access_token": access_token, 'id': cur[0]['id'], 'favorites': favorites}
    return response

@app.route('/signup', methods=["POST"])
def create():

    email = request.json.get("email", None)
    password = request.json.get("password", None)
    if not check_unique_mail(email):
        return {'msg' : f"{email} has already been used"}, 401

    securePassword, salt = secure(password)
    change_db("insert into accounts (email, password, salt) values (?, ?, ?)", (email, securePassword, salt))
    print('compte bien crée')
    
    curAccount = query_db('select id from accounts where email=?', (email,), one=True)

    curFavorites = query_db('select * from favorites where account_id=?', (curAccount[0]['id'],))
    favorites = []
    for elem in curFavorites:
        favorites += [elem['mealId']]
    access_token = create_access_token(identity=email)

    response = {"access_token": access_token, 'id': curAccount[0]['id'], 'favorites': favorites}
    return response

@app.route('/favorites', methods=["POST"])
@jwt_required()
def my_profile():

    response = {'body': []}
    account_id = request.json.get("id", None)
    cur = query_db('select * from favorites where account_id=?', (account_id,))
    for elem in cur:
        response['body'] += [elem['mealId']]
    return response

if __name__ == "__main__":
    app.run(debug=True)