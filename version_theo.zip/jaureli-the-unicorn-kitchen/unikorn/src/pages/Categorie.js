export default function Categorie()
{
    return <div>
        <p>This is the Categorie page</p>
    </div>
}