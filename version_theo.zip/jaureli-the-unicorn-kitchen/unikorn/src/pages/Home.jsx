import React, {useEffect, useState} from 'react'
import axios from 'axios'
import MediaCard from '../components/Card'
import '../Styles/CardsHomepage.css'

const Home = () => {

    const [randomMealList, setRandomMealList] = useState([])

    useEffect(() => {

        if (randomMealList.length != 0){
            console.log('deja des plats', randomMealList) // à chier
        }
        else{
                
        for (let i = 0; i < 3; i++){
            
            axios.get('https://www.themealdb.com/api/json/v1/1/random.php')
                .then((response) => {
                if (randomMealList.find((meal) => meal.id === response.data.meals[0].idMeal)){
                    console.log('dejadedans')
                    i--
                }
                else{
                    let temp = response.data.meals[0]
                    setRandomMealList((prevState) => ([
                        ...prevState,
                        {
                            'id': temp.idMeal,
                            'name': temp.strMeal,
                            'thumb': temp.strMealThumb,
                            'desc': temp.strInstructions.slice(0, 50) + '[...]'
                        },
                    ]))
                }
                })
                .catch((error) => {
                    
                    if (error.response) {
                        console.log(error.response)
                        console.log(error.response.status)
                        console.log(error.response.headers)
                        }
                    else if (error.request) {
                        // The request was made but no response was received
                        console.log(error.request);
                    }
                    else {
                        // Something happened in setting up the request that triggered an Error
                        console.log('Error', error.message);
                    }
                })
        }
    }
    }, [])

    console.log(randomMealList)
    const randomMeals = randomMealList.map((meal, key) => {
        return (
            <li key={key}>
            <MediaCard id={meal.id} name={meal.name} thumb={meal.thumb} desc={meal.desc} />
            </li>
        )
    })
  return (
      <>
    <ul>
        {randomMeals}
    </ul>
    </>
  )
}

export default Home