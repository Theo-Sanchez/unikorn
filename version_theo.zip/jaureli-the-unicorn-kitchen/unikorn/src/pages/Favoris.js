import Box from '@mui/material/Box';
import axios from 'axios';
import React, {useState, useEffect} from 'react'
import MediaCard from '../components/Card'

export default function Favoris() { 

    const [fav, setFav] = useState([])

    let favTest = JSON.parse(localStorage.getItem('favorites')) || []
    console.log(favTest, 'favtest')

    useEffect( () => {
    if (favTest.length > 0){
        for (let elem of favTest){
            console.log(elem, 'id du plat')
            axios.get(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${elem}`)
            .then((response) => {
                let temp = response.data.meals[0]
                setFav((prevState) => ([
                    ...prevState,
                    {
                        'id': temp.idMeal,
                        'name': temp.strMeal,
                        'thumb': temp.strMealThumb,
                        'desc': temp.strInstructions.slice(0, 50) + '[...]'
                    },
                ]))
            })
            .catch((error) => {
                console.log('error')
                // ...
            })
        }
    }
    }, [])
    const favorites = fav.map( (f, key) => {
        return (
            <li key={key}>
                <MediaCard id ={f.id} name={f.name} thumb={f.thumb} desc={f.desc} />
            </li>
        )
    })
    return (
    <>
        <p>This is the Favoris page</p>
        <ul>
            {favorites}
        </ul>
    </>
    )
}