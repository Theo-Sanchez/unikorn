import Recherche from '../components/Recherche'
import Box from '@mui/material/Box';

export default function Search()
{
    return <div>
        <p>This is the Search page</p>
        <Box sx={{width:1/2, m: '10px auto' }}>
        <Recherche />
        </Box>
    </div>
}