import {Link} from 'react-router-dom'
import Categorie from "./Categorie";


export default function Categories()
{
    return (<div>
        <p>This is the <Link to="/categorie" element={Categorie}> lien </Link> vers la page Categorie chakal</p>
    </div>)
}