export default function Inscription()
{
    return <div>
        <p>This is the Inscription page</p>
    </div>
}