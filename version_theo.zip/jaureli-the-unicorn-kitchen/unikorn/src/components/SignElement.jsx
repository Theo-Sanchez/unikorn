import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom'

import {Box, TextField } from '@mui/material';
import axios from "axios";
import '../Styles/GlobalStyle.css'
const SignElement = ({setToken, formType, setFavorites}) => {
    
  
    const [input, setInput] = useState({
      email: '',
      password: ''
    })
    const navigate = useNavigate()

    function sign (signup=false) {
      
      const url = signup ? 'signup' : 'signin'
      axios({
        method: "POST",
        url:`/${url}`,
        data:{
          email: input.email,
          password: input.password
         }
      })
      .then((response) => {
        setToken(response.data.access_token, response.data.id)
        console.log(response.data.favorites, 'test')
        setFavorites(response.data.favorites)
        signup ?
          navigate('/successLog', { replace: true }) :
          navigate('/successSign', { replace: true })
        console.log('wtf')

      }).catch((error) => {
        if (error.response) {
          console.log(error.response)
          console.log(error.response.status)
          console.log(error.response.headers)
          }
      })
  
      setInput({
        email: "",
        password: ""
      })
    }
  
      const handleSubmit = (e) => {

        e.preventDefault()
        formType === 'Sign In' ? sign() : sign(true)
      }

    const handleChange = (e) => {
        setInput( (prevState) => ({
          ...prevState, [e.target.name]: e.target.value
        }))
    }

    

    return (
      <>
        <Box
          component="form"
          sx={{
            '& > :not(style)': { m: 1, width: '25ch' },
          }}
          noValidate
          autoComplete="off"
        >
          <TextField 
            id="outlined-basic"
            label='email'
            name='email' 
            variant="outlined" 
            value={input.email} 
            onChange={handleChange}
          />
          <TextField 
            id="outlined-basic" 
            label='password' 
            name='password' 
            type='password' 
            variant="outlined" 
            value={input.password} 
            onChange={handleChange}
          />
        </Box>
        <button className='button-styled' onClick={handleSubmit} type='submit'>Submit</button>
        
      </>
      );
}

export default SignElement