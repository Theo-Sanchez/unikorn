import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'

const Succes = ({type}) => {

    const navigate = useNavigate()

    useEffect(() => {
      const timeout = setTimeout(() => 
      navigate('/', {replace:true}), 5000)
      return () => clearTimeout(timeout)
    }, [])
    
    
  return (
    <>
    
    {type === 'signin' ?
        (<h3>Congratulations you succesfully logged in</h3>) :
        (<h3>Congratulations your account was successfully created</h3>)
    }
    <p> You'll be redirected to the Home Page in a few</p>
    </>
  )
}

export default Succes