import React from 'react'
import '../Styles/Title.css'


const Title = () => {
  return (
      <>
    <div className="placemat"></div>
    <div className="bowl">
    <div className="text">Lets Cook<br />Eat</div>
    </div>
    </>
  )
}

export default Title