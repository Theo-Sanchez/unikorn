import * as React from "react";
import { useTheme } from "@mui/material/styles";
import {OutlinedInput, InputLabel, MenuItem, FormControl, Select, Box} from "@mui/material/";


const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};


function getStyles(name, personName, theme) {
  return {
    fontWeight:
      personName.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}

export default function SelectCategorie(handleSubmit) {
  const theme = useTheme();
  const [personName, setPersonName] = React.useState([]);
  const [categories, setCategories] = React.useState([]);
  React.useEffect(() => {
    const url = "https://www.themealdb.com/api/json/v1/1/categories.php";
    fetch(url)
      .then((response) => {
        if (response.ok) {
          console.log("ok", response);
          return response.json()
        }
        // throw response;
      })
      .then((result) => {
        console.log(result.categories)
        setCategories(result.categories);
      })
      .catch((error) => {
        console.log("error :", error);
      });
  }, []);

  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setPersonName(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };

  const handleCategory = (id)=>
  {
    return 'ah';
  }

  return (
    <div>
      <Box>
        <FormControl sx={{ m: 1, width: 300 }}>
          <InputLabel id="demo-multiple-name-label">Name</InputLabel>
          <Select
            labelId="demo-multiple-name-label"
            id="demo-multiple-name"
            multiple
            value={personName}
            onChange={handleChange}
            input={<OutlinedInput label="Name" />}
            MenuProps={MenuProps}
          >
            {categories.map((category) => (
              <MenuItem
                key={category.idCategory}
                value={category.idCategory}
                onChange={()=>{
                  handleCategory(category.idCategory) /* remplacer submit */
                }}
              >
                {category.strCategory} {console.log(category.strCategory)}
                
                {/* link maj le rooter seul regarder fx LINK rooter pour afficher resultat en dessous de la recherche*/}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Box>
    </div>
  );
}
