import React from "react";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";

import Categories from "./pages/Categories";
import Categorie from "./pages/Categorie";
import Favoris from "./pages/Favoris";
import Search from "./pages/Search";
import Home from './pages/Home'


import Sign from './components/Sign'
import Success from './components/Success'
import Recherche from './components/Recherche'
import RechercheAnicet from './components/RechercheAnicet'
import Title from './components/Title'

import home_img from './Images/home-cook.png'
import home_img_square from './Images/home-cook-square.png'


import Box from '@mui/material/Box';
import './Styles/App.css'


import useToken from './hooks/useToken'
import useFavorites from './hooks/useFavorites'
const App = () => {

    const { token, id, removeToken, setToken } = useToken();
    const { favoritesIds, removeAllFavorites, setFavorites } = useFavorites();

    const disconnect = () => {
      removeToken()
      removeAllFavorites()
    }

    return(
    <>
    <BrowserRouter>
    <div className="Header-main-wrap">
      <nav>
        <div className="navBarElement">
          <Link to="/">Home</Link>
        </div>
        <div className="navBarElement">
          <Link to="/categories">Categories</Link>
        </div>
        <div className="navBarElement">
          <Link to="/search">Search</Link>
        </div>
        
        {token !== null ? (
        <div className="navBarElement">
          <Link to="/favoris">Favoris</Link>
        </div>) : 
        (<div className="navBarElement">
          <Link to="/inscription">Sign In</Link>
        </div>)
        }
      </nav>
      <Box sx={{width:1/2, m: '10px auto', minHeight:'200px'}}>
        <Recherche />
        </Box>
      </div>
      <p>token: {token}</p>
      <p>id: {id}</p>
        {!token && token !== "" && token !== undefined ? ('') : (
          <button onClick={disconnect}> remove the Token</button>)
        }
      <Routes>
        <Route index path="/" element={<Home />} />

        <Route path="categories">
          <Route path="" element={<Categories />} />
          <Route path="categorie/:id" element={<Categorie />} />
        </Route>

        <Route path="/search" element={<Search />} />
        <Route path="/inscription" element={<Sign token={token} removeToken={removeToken} setToken={setToken} setFavorites={setFavorites}/>}/>
        <Route path="/successLog" element={<Success type='signin'/>} />
        <Route path="/successSign" element={<Success type='signup'/>} />

        <Route path="/favoris" element={<Favoris />} />
      </Routes>
    </BrowserRouter>
    </>
    )
  }

  export default App