import { useState } from 'react';

function useToken() {

  function getToken() {
    
    const userToken = localStorage.getItem('token');
    const userId = localStorage.getItem('id')
    return {
      'token' : userToken,
      'id' : userId
    }
  }
  const [user, setUser] = useState(getToken());

  function saveToken(userToken, userId) {
    
    localStorage.setItem('token', userToken);
    localStorage.setItem('id', userId);
    setUser({
      'token' : userToken,
      'id' : userId
    });
  };

  function removeToken() {

    localStorage.removeItem("token");
    localStorage.removeItem("id");
    setUser({
      'token': null,
      'id': null
    });
  }
  return {
    setToken: saveToken,
    token: user.token,
    id: user.id,
    removeToken
  }
}

export default useToken;