import {useState} from 'react'
import axios from 'axios'


const useFavorites = () => {

    // const getFavorites = (id) => {

    //     let favoriteList
    //     axios({
    //         method: "POST",
    //         url:'/favorites',
    //         data:{
    //             id: id,
    //            },
    //         headers: {
    //         Authorization: 'Bearer ' + token
    //         }
            
    //       })
    //       .then((response) => {
    //           console.log(response.data.body, 'body')
    //           console.log(response.data, 'data')

    //         favoriteList = response.data.body
    //       })
    //       .catch((error) => {
                    
    //         if (error.response) {
    //             console.log('error')
    //             // ...
    //             }
    //     })
    //     return favoriteList
    // }
    function getFavorites() {
        const favorites = JSON.parse(localStorage.getItem('favorites'));
        return favorites && favorites
      }

    const [favoritesIds, setFavoritesIds] = useState(getFavorites())

    const saveFavorite = (favorite_list) => {

      localStorage.setItem('favorites', JSON.stringify(favorite_list))
      console.log(favorite_list)
      for (let list_elem of favorite_list){
      setFavoritesIds((prevState) => ({
        ...prevState,
        list_elem
      }))
      console.log(favoritesIds, 'favs dans useFav')
    }
    }

    const removeAllFavorites = () => {
    
      localStorage.removeItem("favorites");
      setFavoritesIds(null)
    }

    const removeFavorite = (favorite_id) => {
    
      localStorage.removeItem("favorites");
      let favs = [...favoritesIds]
      favs = favs.filter((fav) => fav !== favorite_id)
      console.log(favs, 'favs dans useFav')
      setFavoritesIds(favs)
    }

    return {
        setFavorites: saveFavorite,
        favoritesIds,
        removeAllFavorites
    }
}

export default useFavorites